I, Jingjia Xu, have read and understood the Spring CSE12 syllabus and Personal Responsibility Document. jxu228 7 April 2021
