Mary Xu
1829011
Spring 2021
Lab 4: Functions and Graphics

-----------
DESCRIPTION

In this lab, the users will build several well orgnaized arrays, memory for input/output, subroutine, macros, and stack to build a graphic picture using RGB colors. There will be different colors of horizontal and vertical lines on the display.

-----------
FILES


-
lab4.asm

This includes all the code, command, rrays, memory for input/output, subroutine, macros, and stack for the MIPS ISA for the lab to bulid a graphic display.


-
README.txt

This file includes the description of the lab.


-----------
INSTRUCTIONS

This lab is intend to give an understanding of functions and graphic. Using input and outputs to set the pixcles of x and y, in order to create a graph on the display.