Mary Xu
1829011
Spring 2021
Lab 1: Intro to Logic Simulation

-----------
DESCRIPTION

In this lab, the users will enter and create cricuts, in order to light the 7 fragment component and LED light up by using the truth table.


-----------
FILES


-
Lab1.lgi

This includes the code and the design cricuts of the lab.


-
README.txt

This file includes the description of the lab.


-----------
INSTRUCTIONS

This lab is intend to give a introduction to logic simulation. By running cricuts and click the switch, it will light up the light. This is a program that using MML to run.