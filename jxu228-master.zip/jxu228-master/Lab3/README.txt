Mary Xu
1829011
Spring 2021
Lab 3: ASCII-risk (Asterisks)

-----------
DESCRIPTION

In this lab, the users will build several well orgnaized loop to print out a nest triangle that contains number and stars.  By giving the input number of height, the program will run and persent a neat triangle which the number of lines will match the given input. 

-----------
FILES


-
Lab3.asm

This includes all the code, command, and loop for the MIPS ISA for the lab to bulid a triangle.


-
README.txt

This file includes the description of the lab.


-----------
INSTRUCTIONS

This lab is intend to give a introduction to MIPS ISA using MARS. By running the code and loop, it will create a variable-sized triangle and a sequence of embedded numbers. 