Mary Xu
1829011
Spring 2021
Lab 2: Simple Data Path

-----------
DESCRIPTION

In this lab, the users will build a sequential logic circuit and introduce data paths. The data path will show how the data will transfer thoughout the system. By creating a 4-bit register file, ALU, and user input, there will be a data path running though the project. It is not allow to use the ALU in the mml, so created one using the add all function by ANDand NOR gate. Also in the 4-bit register file, there will be an address to each one of the file that had been created. The value in the address will be saved to a destination that comes from the keypad input or the ALU output. At last, the ALU will calculte the number that had been saved in the ALU input.


-----------
FILES


-
Lab2.lgi

This includes the register file and the design of the ALU of the lab.


-
README.txt

This file includes the description of the lab.


-----------
INSTRUCTIONS

This lab is intend to give a introduction to data path. By running the register file, ALU, user input and an add all function, it will shown how the data will flows in a system. This is a program that using MML to run.